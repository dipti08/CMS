<?php
// to make the values as constant to make the data more secure, we create an array.
$db['db_host'] = "localhost";
$db['db_user'] = "root";
$db['db_pass'] = "";
$db['db_name'] = "cms";

foreach($db as $key => $value)
{
    //this function will make the key name as capital. here it will work as define("$DB_HOST",localhost); but here we will not write this format but will make define work on its own. we need to make the key values to uppercase to make them as constants.
    define(strtoupper($key),$value);
}

$connection=mysqli_connect(DB_HOST,DB_USER,DB_PASS,DB_NAME); //we use the capital contants now because the key values are already converted o uppercase by the previous for loop.
//if($connection)
//{
//    echo "we are connected now";
//}
/*
$connection = mysqli_connect('localhost','root','','cms'); //we pass localhost, then the name of the host, password which is empty here then the database name
if($connection)
{
    echo "yes";
}
*/

?>