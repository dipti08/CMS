<?php include "db.php"; //here we writing only db.php because login and db php files are present inside the same folder. ?>
<?php session_start(); ?>

<?php
if(isset($_POST['login']))
{
    $username=$_POST['username'];
    $password=$_POST['password'];
    
    $username=mysqli_real_escape_string($connection,$username); //cleaning it up and assigning to the same variable.
    $password=mysqli_real_escape_string($connection,$password);
    
    $query="SELECT * FROM users where username='{$username}' ";
    $select_user_query=mysqli_query($connection,$query);
    if(!$select_user_query)
    {
        die("QUERY FAILED. ".mysqli_error($connection));
    }
    while($row=mysqli_fetch_array($select_user_query))
    {
        $db_user_id=$row['user_id'];
        $db_username=$row['username'];
        $db_password=$row['password'];
        $db_user_firstname=$row['user_firstname'];
        $db_user_lastname=$row['user_lastname'];
        $db_user_role=$row['user_role'];
    }
    //$password=crypt($password,$db_password);
    
    /* this can be done in another easier way which is shown below
    if($username != $db_username && $password != $db_password)
    {
        header("Location: ../index.php");
    }
    else if($username == $db_username && $password == $db_password)
    {
        $_SESSION['username']=$db_username;     //username will be the variable that will be used to store the $db_username variable. so if use echo somewhere else and have our session turned on, whenever we will want to access this username, we can use the 'username' variable. We assign from right to left.
        $_SESSION['firstname']=$db_user_firstname;
        $_SESSION['lastname']=$db_user_lastname;
        $_SESSION['user_role']=$db_user_role;
        header("Location: ../admin");
    }
    else
    {
        header("Location: ../index.php");
    }*/
        
    //if($username === $db_username && $password === $db_password) //three equals means exactly identical.
    if(password_verify($password,$db_password))
    {
        $_SESSION['username']=$db_username;  
        $_SESSION['firstname']=$db_user_firstname;
        $_SESSION['lastname']=$db_user_lastname;
        $_SESSION['user_role']=$db_user_role;
        header("Location: ../admin");
    }
    else
    {
        header("Location: ../index.php");   
    }
    
    
}


?>