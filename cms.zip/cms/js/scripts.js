
    //CKEDITOR
//this editor is not working for me
/*ClassicEditor
    .create(document.querySelector('#editor'))
    .catch( error = > {
        console.error(error);
    });
     
*/

//with the javascript we want that when we will click on the main checkbox, then all the other elements must be checkboxed.


$(document).ready(function())
{
    alert(hello!);
}