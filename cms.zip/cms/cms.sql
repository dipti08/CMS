-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2020 at 12:02 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.2.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cms`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(3) NOT NULL,
  `cat_title` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(2, 'Javascript'),
(3, 'PHP'),
(10, 'JAVA'),
(11, 'TEST');

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(3) NOT NULL,
  `comment_post_id` int(3) NOT NULL,
  `comment_author` varchar(255) NOT NULL,
  `comment_email` varchar(255) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_status` varchar(255) NOT NULL,
  `comment_date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `comment_post_id`, `comment_author`, `comment_email`, `comment_content`, `comment_status`, `comment_date`) VALUES
(5, 2, 'Cindy', 'Cindy@gmail.com', 'This example is for testing.', 'approved', '2019-07-16'),
(8, 2, 'Peter', 'peter@gmail.com', 'This course is awesome.', 'approved', '2019-07-16'),
(14, 16, 'Jessy', 'Jessy@gmail.com', 'Hi, there', 'unapproved', '2020-01-30');

-- --------------------------------------------------------

--
-- Table structure for table `postss`
--

CREATE TABLE `postss` (
  `post_id` int(3) NOT NULL,
  `post_category_id` int(3) NOT NULL,
  `post_title` varchar(255) NOT NULL,
  `post_author` varchar(255) NOT NULL,
  `post_user` varchar(255) NOT NULL,
  `post_date` date NOT NULL,
  `post_image` text NOT NULL,
  `post_content` text NOT NULL,
  `post_tags` varchar(255) NOT NULL,
  `post_comment_count` varchar(11) NOT NULL,
  `post_status` varchar(255) NOT NULL DEFAULT 'draft',
  `post_view_count` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `postss`
--

INSERT INTO `postss` (`post_id`, `post_category_id`, `post_title`, `post_author`, `post_user`, `post_date`, `post_image`, `post_content`, `post_tags`, `post_comment_count`, `post_status`, `post_view_count`) VALUES
(2, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '1', 'published', 12),
(3, 1, 'Example Post', 'Dipti Agarwal', '', '2019-07-17', 'image_1.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur mollis vitae velit non pharetra. Fusce libero lorem, venenatis vitae molestie quis, vehicula quis velit. Curabitur eleifend ipsum sit amet bibendum iaculis. Nulla facilisi. Nulla ultrices justo ut aliquam rutrum. Vivamus efficitur, quam quis tristique dapibus, quam mi sollicitudin mauris, eget interdum urna eros vitae risus. Integer ac vestibulum lectus, euismod sollicitudin dolor. Ut sed consectetur odio. Mauris at ex in massa tincidunt bibendum.            \r\n                    \r\n                    \r\n                    \r\n        ', 'example, test, post, extra', '5', 'published', 0),
(4, 10, 'Title', 'Jimmy Kemmel', '', '2019-07-20', 'image_4.jpg', 'This course is a must learn.', 'Java, course, classes, learn', '', 'published', 0),
(5, 1, 'Edwin CMS PHP Coursee', 'Edwin Diaz', '', '2019-07-22', 'image_2.jpg', 'This course is awesome.            \r\n                    \r\n                    \r\n        ', 'edwin, javascript, php, niceee', '', 'published', 1),
(6, 1, 'Bootstrapp', 'Dipti Agarwal', '', '2019-07-20', 'image_3.jpg', 'This course will help in learning the basics of html, css and bootstrap.', 'bootstrap, html, css, fundamental', '', 'published', 0),
(7, 1, 'Test', 'Raman Kumar', '', '2019-07-22', 'image_1.jpg', 'This is just for a practice session.            \r\n        ', 'test, extra, practice, daily', '', 'published', 0),
(8, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 0),
(9, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 0),
(10, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 0),
(11, 1, 'Bootstrapp', 'Dipti Agarwal', '', '2019-07-22', 'image_3.jpg', 'This course will help in learning the basics of html, css and bootstrap.', 'bootstrap, html, css, fundamental', '', 'published', 0),
(12, 1, 'Edwin CMS PHP Coursee', 'Edwin Diaz', '', '2019-07-22', 'image_2.jpg', 'This course is awesome.            \r\n                    \r\n                    \r\n        ', 'edwin, javascript, php, niceee', '', 'published', 1),
(13, 1, 'Edwin CMS PHP Coursee', 'Edwin Diaz', '', '2019-07-22', 'image_2.jpg', 'This course is awesome.            \r\n                    \r\n                    \r\n        ', 'edwin, javascript, php, niceee', '', 'published', 0),
(14, 1, 'Bootstrapp', 'Dipti Agarwal', '', '2019-07-22', 'image_3.jpg', 'This course will help in learning the basics of html, css and bootstrap.', 'bootstrap, html, css, fundamental', '', 'published', 0),
(15, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 0),
(16, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 2),
(17, 1, 'Javascript Course', 'Daniel ', '', '2019-07-22', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'published', 1),
(19, 1, 'Bootstrapp', 'Dipti Agarwal', '', '2019-07-22', 'image_3.jpg', 'This course will help in learning the basics of html, css and bootstrap.', 'bootstrap, html, css, fundamental', '', 'published', 0),
(20, 1, 'Edwin CMS PHP Coursee', 'Edwin Diaz', '', '2019-07-22', 'image_2.jpg', 'This course is awesome.            \r\n                    \r\n                    \r\n        ', 'edwin, javascript, php, niceee', '', 'published', 1),
(21, 10, 'Title', 'Jimmy Kemmel', '', '2019-07-22', 'image_4.jpg', 'This course is a must learn.', 'Java, course, classes, learn', '', 'published', 1),
(22, 1, 'Example Post', 'Dipti Agarwal', 'demo', '2019-07-28', 'image_1.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur mollis vitae velit non pharetra. Fusce libero lorem, venenatis vitae molestie quis, vehicula quis velit. Curabitur eleifend ipsum sit amet bibendum iaculis. Nulla facilisi. Nulla ultrices justo ut aliquam rutrum. Vivamus efficitur, quam quis tristique dapibus, quam mi sollicitudin mauris, eget interdum urna eros vitae risus. Integer ac vestibulum lectus, euismod sollicitudin dolor. Ut sed consectetur odio. Mauris at ex in massa tincidunt bibendum.            \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'example, test, post, extra', '', 'published', 4),
(23, 1, 'Javascript Course', 'Daniel ', 'dipti', '2019-07-28', 'image_5.jpg', 'This course is worth studying            \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n                    \r\n        ', 'javascript, course, learn, must', '', 'draft', 15),
(25, 1, 'Edwin CMS PHP Coursee', '', 'dipti', '2019-07-28', 'image_2.jpg', 'ejfoiwhdficjdpicjpd            \r\n                    \r\n                    \r\n                    \r\n        ', 'kvojojdomasodkoaks', '', 'draft', 2),
(26, 2, 'Javascript', '', 'peter', '2019-07-28', 'image_4.jpg', 'fi8thkhoo-0898re5shoiy8oy8y9-907y7f', 'vhguguihigydrysuytiyoy8t5sw46w6465r', '', 'draft', 3),
(27, 10, 'Edwin CMS PHP Coursee', '', 'jimmy', '2019-07-28', 'image_1.jpg', 'hi there! this course is awesome', 'Java, course, classes', '', 'published', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(3) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_firstname` varchar(255) NOT NULL,
  `user_lastname` varchar(255) NOT NULL,
  `user_email` varchar(255) NOT NULL,
  `user_image` text NOT NULL,
  `user_role` varchar(255) NOT NULL,
  `randSalt` varchar(255) DEFAULT '$2y$10$iusesomecrazystrings22'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `username`, `password`, `user_firstname`, `user_lastname`, `user_email`, `user_image`, `user_role`, `randSalt`) VALUES
(37, 'demo', '$2y$12$A9xfJErgJri/60leL0B8xOUHyhJ31JOX1E.Twvp5pjk2Im6CUAPNa', 'Demo', 'Guru', 'demo@gmail.com', '', 'subscriber', '$2y$10$iusesomecrazystrings22'),
(39, 'dipti', '$2y$12$rrmbmnVF39C4G4qSYu29N.E6ZGtRYqianVY20MTqhA7R3gvQlWp9u', 'Dipti', 'Agarwal', 'dp@gmail.com', '', 'admin', '$2y$10$iusesomecrazystrings22'),
(40, 'jimmy', '$2y$10$fexqRwEaemZzuq3Ouo1Veej6SCp5k8ra4ufCBqNkitxMLd7w8ppTa', 'Jimmy', 'Kemmel', 'jimmy@gmail.com', '', 'admin', '$2y$10$iusesomecrazystrings22'),
(41, 'peter', '$2y$10$4jZc2lYzJcoUDJciNMBaD.HDuNaAYXzww6W/dMigiWI4aHc1ydFdO', 'William', 'Peterson', 'peterson@gmail.com', '', 'subscriber', '$2y$10$iusesomecrazystrings22');

-- --------------------------------------------------------

--
-- Table structure for table `users_online`
--

CREATE TABLE `users_online` (
  `id` int(3) NOT NULL,
  `session` varchar(255) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_online`
--

INSERT INTO `users_online` (`id`, `session`, `time`) VALUES
(13, 'hu0vhnqoc94jve4o2cmjk0inbo', 1563823106),
(14, 'm9cphh8b3f2madqk6hfrl4m4j8', 1563822962),
(15, 'vr6oabppl30v6mjt1amsrgco6a', 1563822957);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`);

--
-- Indexes for table `postss`
--
ALTER TABLE `postss`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users_online`
--
ALTER TABLE `users_online`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `postss`
--
ALTER TABLE `postss`
  MODIFY `post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `users_online`
--
ALTER TABLE `users_online`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
