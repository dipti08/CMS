<?php

echo password_hash('secret',PASSWORD_DEFAULT,array('cost'=>12));
//cost is the amount of time that will take to give us a new hash. Bigger the number is, slower is the software but it is beneficial because now the passwords will get changed at a slower rate.
//we will be using BCRYPT algorithm and that too the CRYPT_BOWFISH algorithm.


?>