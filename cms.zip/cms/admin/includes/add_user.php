<?php
//we need to make a form in order to add posts. 
//the form is a bit different because we will be uploading a picture using this form because of which we will use the tag called 'enctype'
if(isset($_POST['create_user']))
{
    $user_firstname=$_POST['user_firstname'];  //user_ is the name of the input type.
    $user_lastname=$_POST['user_lastname'];
    $user_role=$_POST['user_role'];

    $username=$_POST['username'];
    $user_email=$_POST['user_email'];
    $user_password=$_POST['password'];
    //$post_date=date('d-m-y');
   // $post_comment_count=4; //initially hard coding it so that the box in the database does not remain empty. After sometime we do not want to hard code it but want the data to be dynamically be there and so delete the {$post_comment_count} from the query also.
    
    $user_password=password_hash($user_password,PASSWORD_BCRYPT,array('cost'=>10)); //now here the time has to be less so that any hacker cannot get insiide our system.
    
    $query="INSERT INTO users(user_firstname,user_lastname,user_role,username,user_email,password)";
    $query.="VALUES('{$user_firstname}','{$user_lastname}','{$user_role}','{$username}','{$user_email}','{$user_password}')";
    
    $create_user_query=mysqli_query($connection,$query);
    confirmQuery($create_user_query);
    echo "User Created: " . " " . "<a href='users.php'>View Users</a> ";
    
}
?>


<form action="" method="post" enctype="multipart/form-data">
    
    <div class="form-group">
        <label for="user_firstname">Firstname</label>
        <input type="text" class="form-control" name="user_firstname">
    </div>
    
    <div class="form-group">
        <label for="user_lastname">Lastname</label>
        <input type="text" class="form-control" name="user_lastname">
    </div>
    
    <!-- Add user requires to insert the data inside the databse and not edit it. The 'php query' part that we wanted here was to choose between the options of the user role that depends on the user if he/she wants to edit it. So, the user role(options or dropdown) should come inside the edit_user page -->   
    
    <div class="form-group">
      
       <select name="user_role" id=""> <!-- here the $cat_title will be displayed to us whose option value is $cat_id which will be carried by the name='post_category' in 'select' syntax -->
      
          <option value="subscriber">Select Options</option>
           <option value="admin">Admin</option>
           <option value="subscriber">Subcriber</option>
                     
       </select>
        
    </div>
    
<!--    <div class="form-group">
        <label for="post_image">Post Image</label>
        <input type="file" name="image">
    </div>
-->
    
     <div class="form-group">
        <label for="username">Username</label>
        <input type="text" class="form-control" name="username">
    </div>
    
    <div class="form-group">
        <label for="user_email">Email</label>
        <input type="email" class="form-control" name="user_email">
    </div>
    
    <div class="form-group">
        <label for="password">Password</label>
        <input type="password" class="form-control" name="password">
    </div>
    
    <div class="form-group">
        <input class="btn btn-primary" type="submit" name="create_user" value="Add User">
    </div>
    
</form>