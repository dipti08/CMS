<?php include "includes/admin_header.php" ?>
    <div id="wrapper">

    <!-- Navigation -->
        <?php include "includes/admin_navigation.php" ?>

        <div id="page-wrapper">

            <div class="container-fluid">

                <!-- Page Heading -->
                <div class="row">
                    <div class="col-lg-12">
                       
                        <h1 class="page-header">
                            Welcome to Comments
                            <small>Author</small>
                        </h1>

<?php
if(isset($_POST['checkBoxArray']))
{
    foreach($_POST['checkBoxArray'] as $commentValueId)
    {
        $bulk_options=$_POST['bulk_options'];
        switch($bulk_options)
        {
            case 'approved':
                $query="UPDATE comment SET comment_status = '{$bulk_options}' WHERE comment_id={$commentValueId}";
                $update_to_approved_status=mysqli_query($connection,$query);
                confirmQuery($update_to_approved_status);
                break;
                
                case 'unapproved':
                $query="UPDATE comment SET comment_status = '{$bulk_options}' WHERE comment_id={$commentValueId}";
                $update_to_unapproved_status=mysqli_query($connection,$query);
                confirmQuery($update_to_unapproved_status);
                break;
                
                case 'delete':
                $query="DELETE FROM comment WHERE comment_id={$commentValueId}";
                $update_to_delete_status=mysqli_query($connection,$query);
                confirmQuery($update_to_delete_status);
                break;
                
                case 'clone':
                $query="SELECT * FROM comment WHERE comment_id='{$commentValueId}' ";
                $select_comment_query=mysqli_query($connection,$query);
                while($row=mysqli_fetch_array($select_comment_query))
                {
                    $comment_id=$row['comment_id'];
                    $comment_post_id=$row['comment_post_id'];
                    $comment_author=$row['comment_author'];
                    $comment_email=$row['comment_email'];
                    $comment_content=$row['comment_content'];
                    $comment_status=$row['comment_status'];
                    $comment_date=$row['comment_date'];
                }
                
                $query="INSERT INTO comment(comment_id, comment_post_id, comment_author, comment_email, comment_content, comment_status, comment_date) ";
                $query.="VALUES({$comment_id}, $comment_post_id, '{$comment_author}', '{$comment_email}', '{$comment_content}', '{$comment_status}', now() ) ";
                $copy_query=mysqli_query($connection,$query);
                confirmQuery($copy_query);
                break;
                
                
                
        }
    }
}
?>
                           

                           
                           
                           <table class="table table-bordered table-hover">
                           <div id="bulkOptionsContainer">
                               
                               <select name="bulk_options" id="form-control" class="col-xs-4">
                                   <option value="">Select Options</option>
                                   <option value="approved">Approve</option>
                                   <option value="unapproved">Unapprove</option>
                                   <option value="delete">Delete</option>
                                   <option value="clone">Clone</option>
                                </select>
                               
                           </div>
                           <div class="col-xs-4">
                               <input type="submit" name="submit" class="btn btn-success" value="Apply">
                           </div>
                           
                            <thead>
                                <tr>
                                   <th><input id="selectAllBoxes" type="checkbox"></th>
                                    <th>Id</th>
                                    <th>Author</th>
                                    <th>Comment</th>
                                    <th>Email</th>
                                    <th>Status</th>
                                    <th>In Response To</th>
                                    <th>Date</th>
                                    <th>Approve</th>
                                    <th>Unapprove</th>
                                    <th>Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                
                                $query='SELECT * FROM comment WHERE comment_post_id=".$_GET['id']."'; mysqli_real_escape_string($connection,$_GET['id']);
                                //$query="SELECT * FROM categories LIMIT 3";  //limit is used to show only mentioned number of queries
                                $select_comments=mysqli_query($connection,$query);
                                while($row=mysqli_fetch_assoc($select_comments))
                                {
                                    $comment_id=$row['comment_id'];
                                    $comment_post_id=$row['comment_post_id'];
                                    $comment_author=$row['comment_author'];
                                     $comment_content=$row['comment_content'];
                                    $comment_email=$row['comment_email'];
                                   
                                    $comment_status=$row['comment_status'];
                                    $comment_date=$row['comment_date'];                             
                                    
                                    echo "<tr>";
                                    ?>
                                    
                                    <td><input class='checkBoxes' type='checkbox' name='checkBoxArray[]' value='<?php echo $post_id; ?>'></td>
                                    
                                    <?php
                                    
                                    echo "<td>$comment_id</td>";
                                    echo "<td>$comment_author</td>";
                                    echo "<td>$comment_content</td>";
                                    /*
                                    $query="SELECT * FROM categories WHERE cat_id = {$post_category_id} ";
                                    //$query="SELECT * FROM categories LIMIT 3";  //limit is used to show only mentioned number of queries
                                    $select_categories_id=mysqli_query($connection,$query);
                                    while($row=mysqli_fetch_assoc($select_categories_id))
                                    {
                                        $cat_id=$row['cat_id'];
                                        $cat_title=$row['cat_title'];
                                        
                                        echo "<td>{$cat_title}</td>";
                                    }
                                    */
                                    
                                    echo "<td>$comment_email</td>";
                                    echo "<td>$comment_status</td>";
                                    
                                    $query="SELECT * FROM postss WHERE post_id={$comment_post_id}";
                                    $select_post_id_query=mysqli_query($connection,$query);
                                    while($row=mysqli_fetch_assoc($select_post_id_query))
                                    {
                                        $post_id=$row['post_id'];
                                        $post_title=$row['post_title'];
                                        
                                         echo "<td><a href='../post.php?p_id={$post_id}'>$post_title</a></td>"; 
                                        //we do not show comment_post_id as it will be an inresposive field, so here just for example we are showing it as hard coded.
                                    }
                                    
                                
                                    echo "<td>$comment_date</td>";
                                    echo "<td><a href='post_comments.php?approved={$comment_id}&id=".$_GET['id']."'>Approve</a></td>";
                                    echo "<td><a href='post_comments.php?unapproved={$comment_id}&id=".$_GET['id']."'>Unapprove</a></td>";
                                    echo "<td><a href='post_comments.php?delete={$comment_id}&id=".$_GET['id']."'>Delete</a></td>";
                                    echo "</tr>";
                                    
                                }
                                
                                ?>
                                    
                                
                            </tbody>
                        </table>
                        
<?php

if(isset($_GET['approved']))
{
    $the_comment_id=$_GET['approved'];
    $query="UPDATE comment SET comment_status = 'approved' WHERE comment_id = {$the_comment_id}";
    $approve_comment_query=mysqli_query($connection,$query);
    header("Location: post_comments.php?id=" . $_GET['id'] ."");
}


if(isset($_GET['unapproved']))
{
    $the_comment_id=$_GET['unapproved'];
    $query="UPDATE comment SET comment_status = 'unapproved' WHERE comment_id = {$the_comment_id}";
    $unapprove_comment_query=mysqli_query($connection,$query);
    header("Location: post_comments.php?id=" . $_GET['id'] ."");
}

if(isset($_GET['delete']))
{
    $the_comment_id=$_GET['delete'];
    $query="DELETE FROM comment WHERE comment_id = {$the_comment_id}";
    $delete_query=mysqli_query($connection,$query);
    header("Location: post_comments.php?id=" . $_GET['id'] ."");
}

?>

     
</div>
</div>
<!-- /.row -->

</div>
<!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php include "includes/admin_footer.php";  ?>                        