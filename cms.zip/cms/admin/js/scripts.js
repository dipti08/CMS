
    //CKEDITOR
//this editor is not working for me
/*ClassicEditor
    .create(document.querySelector('#editor'))
    .catch( error = > {
        console.error(error);
    });
     
*/

//with the javascript we want that when we will click on the main checkbox, then all the other elements must be checkboxed.

/*
$(document).ready(function()
{
    $('#selectAllBoxes').click(function(event)
    {
       if(this.clicked)
           {
               $('.checkBoxes').each(function()
                {
                   this.checked=true; //this is referring to '.checkboxes'
               });
           }
        else{
            $('.checkBoxes').each(function()
                {
                   this.checked=false; //this is referring to '.checkboxes'
               });
        }
    });
    var div_box="<div id='load-screen'><div id='loading'></div></div>";
    $("body").prepend(div_box);
    $('#load-screen').delay(700).fadeOut(600,function()
    {
        $(this).remove();
    });
    
    
    
});
*/
/*
function loadUsersOnline()
{
    //we need to constantly send information to the database and fetch information from it. We are making this AJAX code so that there is refreshing of the page on its own.
    $.get("functions.php?onlineusers=result",function(data)
    {
        $(".usersonline").text(data);
    });
}
setInterval(function()
{
    loadUsersOnline();
},500); //we are calling the loadUsersOnline at every half a seconf functionality.
*/