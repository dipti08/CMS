
<?php include "includes/db.php"; ?>
<?php include "includes/header.php"; ?>



    <!-- Navigation -->
    <?php include "includes/navigation.php"; ?>
    <!-- Page Content -->
    <div class="container">

        <div class="row">

            <!-- Blog Entries Column -->
            <div class="col-md-8">
                
                <?php
                  $query="SELECT * FROM postss ";
                    $select_all_posts_query=mysqli_query($connection,$query);
                    while($row=mysqli_fetch_array($select_all_posts_query))
                    {
                        $post_id=$row['post_id'];
                        $post_title=$row['post_title']; //'post_title' is the name of the column inside the database
                        $post_author=$row['post_author'];
                        $post_date=$row['post_date'];
                        $post_image=$row['post_image'];
                        $post_content=substr($row['post_content'],0,100);   //this will truncate or cut short the content for a post so that only small amount of data is shown.
                        $post_status=$row['post_status'];
                        
                        //doing on my own and not following sir's code
                        if($post_status == 'published')
                        {
                                            
                        
                        //the loop will run 4 times if there are a total of 4 posts. then if one post is published, it will display all its contents but if the 2nd post is draft, it will show the sorry message which will be wrong.
                        /*if($post_status != 'published')
                        {
                            echo "Sorry, there are currently no published posts.";
                        }
                        else
                        {*/
                            
                ?>
                    
                <h1 class="page-header">
                Page Heading
                <small>Secondary Text</small>
                </h1>

                <!-- First Blog Post -->
                <!-- we are basically looping inside the while loop. So everytime we loop around, we catch a new id. Second time when we will loop, the id, author, image and everything will be different for a different post. -->
                <h2>
                    <a href="post.php?p_id=<?php echo $post_id; ?>"><?php echo $post_title; ?></a>    
                    <!--//when we will click on the post_title, it will send a parameter p_id equals the id of the post_id but we need to catch that p_id. The p_id will be catched on the post.php page.-->
                </h2>
                <p class="lead">
                    by <a href="author_posts.php?author=<?php echo $post_author; ?>&p_id=<?php echo $post_id; ?>"><?php echo $post_author; ?></a>
                </p>
                <p><span class="glyphicon glyphicon-time"></span><?php echo $post_date ?></p>
                <hr>
                <a href="post.php?p_id=<?php echo $post_id; ?>"><img class="img-responsive" src="images/<?php echo $post_image; ?>" alt=""></a>
                <hr>
                <p><?php echo $post_content; ?></p>
                <a class="btn btn-primary" href="post.php?p_id=<?php echo $post_id; ?>">Read More <span class="glyphicon glyphicon-chevron-right"></span></a>

                <hr>
                    
                    <?php
                      } //my if statement ending code
                    //} //closing of else condition
                    } //closing of while loop
                    ?>

                

                

                
               

            </div>

            <!-- Blog Sidebar Widgets Column -->
            <?php include "includes/sidebar.php"; ?>

        </div>
        <!-- /.row -->

        <hr>

<?php include "includes/footer.php"; ?>